create database if not exists hr_attribution_db;
use hr_attribution_db;
create table if not exists hr_attribution(EmployeeID SERIAL, Department varchar(50), 
JobRole	VARCHAR(50), Attrition varchar(50), Gender VARCHAR(30), Age int, MaritalStatus VARCHAR(30), 
Education VARCHAR(30),EducationField VARCHAR(50), BusinessTravel varchar(30), JobInvolvement varchar(30), JobLevel	int, 
JobSatisfaction VARCHAR(30),Hourlyrate int, Income	int,Salaryhike int, OverTime varchar(30), Workex int,YearsSinceLastPromotion int,EmpSatisfaction VARCHAR(30),TrainingTimesLastYear int,WorkLifeBalance VARCHAR(30),Performance_Rating VARCHAR(30),primary key (EmployeeID));
describe hr_attribution;
drop table if exists hr_attribution;

SET GLOBAL local_infile = true;
show tables;
LOAD DATA LOCAL INFILE 'E:/Data/MySQL/HR_Employee.csv' INTO 
TABLE hr_attribution FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

select * from hr_attribution limit 5;

-- 1. Shape of table 
select count(EmployeeID) from hr_attribution;

-- Returns Number of Columns      
select count(*) from information_schema.columns where table_name = 'hr_attribution';

-- 2. Show the count of Employee & percentage Workforce in each Department.
select Department, count(*) as COUNT_EMP from hr_attribution GROUP BY Department ORDER BY COUNT_EMP DESC;

select Department, count(*) as Count_EMP, count(*)*100/(select count(*) from hr_attribution) 
as percentage_dept from hr_attribution group by Department order by Count_EMP desc;

-- 3. Which gender have higher strength as workforce in each department ?
select Department, Gender, count(*) as COUNT_EMP from hr_attribution group by Department, Gender ORDER BY COUNT_EMP;

-- 4. Show the workforce in each JobRole
-- Observation: 

select JobRole, count(*) as COUNT_EMP from hr_attribution group by JobRole  ORDER BY COUNT_EMP desc;

-- 5. Show Distribution of Employee's Age Group
-- ALTER TABLE HR_Employee DROP age_group;
 alter table hr_attribution add column age_group varchar(20);
 
 SET SQL_SAFE_UPDATES = 0;
 
 -- Assign Values to age_group 
 update hr_attribution 
 SET age_group = if ( age <= 25, '<25', if (age > 40, '40+', '25-40'));
 
 select age_group, COUNT(*) as emp_num from hr_attribution GROUP BY age_group;

-- 6. Compare all marital status of emp find the most frequent one.
select MaritalStatus, count(*) as COUNT_MStatus from hr_attribution group by MaritalStatus  ORDER BY COUNT_MStatus desc;

-- 7. What is Jobsatisfaction level of emp
select JobSatisfaction, count(*) as Count_JobSatisfy, count(*)*100/(select count(*) from hr_attribution) 
as Per_JobSatisfy from hr_attribution group by JobSatisfaction order by Per_JobSatisfy desc;

-- 8. How frequently emp are going for business trips
select BusinessTravel, count(*) as Count_BTravel, count(*)*100/(select count(*) from hr_attribution) 
as Per_Trip from hr_attribution group by BusinessTravel order by Per_Trip desc;

-- 9. Show the dept with highest Attrition Rate(Percentage)
-- obs:Highest attrition is in Research & development
select Department,Attrition,count(*) as count_emp , count(*)*100/(select count(*) from hr_attribution) as Per_Attrition from hr_attribution group by Department,Attrition order by Per_Attrition desc;

select Department, sum(case when Attrition = 'Yes' then 1 else 0 end) as count_attr,
round(sum(case when Attrition = 'Yes' then 1 else 0 end)*100/(select count(*) from hr_attribution), 2) as attr_rate from hr_attribution group by
Department;

-- 10- Show JobRole with highest attrition Rate(%)
select JobRole, sum(case when Attrition = 'Yes' then 1 else 0 end) as count_attr,
round(sum(case when Attrition = 'Yes' then 1 else 0 end)*100/(select count(*) from hr_attribution), 2) as attr_rate from hr_attribution group by
JobRole ORDER BY attr_rate DESC;

-- 11. Show distribution of employees promotion find the max chances of emp getting promoted 
-- getting Promoted
-- YearsSinceLastPromotion
select DISTINCT(YearsSinceLastPromotion) from hr_attribution;

alter table hr_attribution add column promotion_group varchar(30);

SET SQL_SAFE_UPDATES = 0;

update hr_attribution 
SET promotion_group = if ( YearsSinceLastPromotion <= 5, '<=5', 
if (YearsSinceLastPromotion > 10, '10+', '6-10')); 
select promotion_group, COUNT(*) as count_num from hr_attribution GROUP BY promotion_group;


-- 12. Find the Atrrition Rate for Marital Status
-- Observation : Highest Attrition is in Singles 
select MaritalStatus, Attrition, count(*) as Count_EMP, count(*)*100/(select count(*) from hr_attribution) 
as Percent_EMP from hr_attribution group by MaritalStatus,Attrition order by Percent_EMP desc;

-- 13. Find the Attrition Count & Percentage for Different Education Levels
-- Observation: Higher Education have Lower Attrition Rate
select Education, Attrition, count(*) as Count_EMP, count(*)*100/(select count(*) from hr_attribution) 
as Percent_EMP from hr_attribution group by Education,Attrition order by Percent_EMP desc;

-- 14. Find the Attrition & Percentage Attrition for Business Travel 
-- Observation: Attrition is High for Employees Travelling Frquently
select BusinessTravel, sum(case when Attrition = 'Yes' then 1 else 0 end) as count_attr, 
round(SUM(if(Attrition = 'yes', 1, 0))/count(*), 2) as attr_rate from hr_attribution group by BusinessTravel;

-- 15. Find the Attrition & Percentage Attrition for Various JobInvolvement
-- Observation: Low Job Involvement Leads to High Attrition Rate
select JobInvolvement, sum(case when Attrition = 'Yes' then 1 else 0 end) as count_attr, 
round(SUM(if(Attrition = 'yes', 1, 0))/count(*), 2) as attr_rate from hr_attribution 
group by JobInvolvement ORDER BY attr_rate;

-- 16. Show Attrition Rate for Different JobSatisfaction
-- Observation: Low Job Satisafaction leads to High Attrition Rate
select JobSatisfaction , sum(case when Attrition = 'Yes' then 1 else 0 end) as count_attr, 
round(SUM(if(Attrition = 'yes', 1, 0))/count(*), 2) as attr_rate from hr_attribution 
group by JobSatisfaction  ORDER BY attr_rate;

